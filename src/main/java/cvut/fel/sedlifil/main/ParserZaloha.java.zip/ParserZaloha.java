package org.jboss.as.quickstarts.kitchensink.javaparser;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.imports.ImportDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitor;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.lang.annotation.Annotation;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by filip on 01.11.17.
 */
public class ParserZaloha {

    private final String filePath;

    private Map<String, ClassWithMethods> classWithMethodsList;
    private Map<String, ClassWithMethods> classWithMethodsListBlock1;
    private Map<String, ClassWithMethods> classWithMethodsListBlock2;
    private Map<String, ClassWithMethods> classWithMethodsListBlock3;
    private static final String BLOCK1_ = "Block1";
    private static final String BLOCK2_ = "Block2";
    private static final String BLOCK3_ = "Block3";


    public ParserZaloha(String filePath) {
        this.filePath = filePath;
        classWithMethodsList = new HashMap<>();
        classWithMethodsListBlock1 = new HashMap<>();
        classWithMethodsListBlock2 = new HashMap<>();
        classWithMethodsListBlock3 = new HashMap<>();

    }

    /**
     * Find ale files in in given directory path and subdirs
     *
     * @param path
     */

    public void findAllClasses(String path) {
        //
        List<String> classNameList = new ArrayList<>();
        List<String> directories = new ArrayList<>();


        Path absPath = Paths.get(path).toAbsolutePath();
        File[] files = new File(absPath.toString()).listFiles();

        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".java")) {
                classNameList.add(file.getName());
            } else if (file.isDirectory()) {
                directories.add(file.getName());
            }
        }

        classNameList.stream().forEach(y -> saveClass(absPath.toString().concat("/" + y)));
        /*System.out.println("Directories:");
        directories.stream().forEach(System.out::println);
        System.out.println("Java classes:");
        classNameList.stream().forEach(System.out::println);
        System.out.println();
        */
        /* recursion for founded directories*/
        for (String s : directories) {
            findAllClasses(path.concat("/" + s));
        }

    }


    /**
     * save finded classes and split into 3set of block depending on annotation
     *
     * @param path
     */
    public void saveClass(String path) {
        CompilationUnit cu;
        try {
            cu = JavaParser.parse(new FileInputStream(path));
            List<String> methodNames = new ArrayList<>();
            VoidVisitor<List<String>> methodVisitor = new MethodNamePrinter();
            methodVisitor.visit(cu, methodNames);


            String className;
            if (path.contains("/")) {
                className = path.substring(path.lastIndexOf('/') + 1, path.length());
            } else {
                className = path;
            }

            ClassWithMethods classWithMethods = new ClassWithMethods(className, path, methodNames);


            //zavolani tridy ClassVisitor a ulozeni vsech anotaci do listu
            List<AnnotationExpr> annotationClassList = new ArrayList<>();
            VoidVisitor<List<AnnotationExpr>> annotationClassVisitor = new ClassVisitor();
            annotationClassVisitor.visit(cu, annotationClassList);

            // najit vsechny importy


            //System.out.println("========================");


            //rozhodnuti kam dana trida poputuje
            for (AnnotationExpr ann : annotationClassList) {
                //System.out.println("ann name: " + ann.getName() + " vs. " + BLOCK1_);
                if (ann.getNameAsString().equals(BLOCK1_)) {
                    classWithMethodsListBlock1.put(classWithMethods.getPath(), classWithMethods);
                    return;
                } else if (ann.getNameAsString().equals(BLOCK2_)) {
                    classWithMethodsListBlock2.put(classWithMethods.getPath(), classWithMethods);
                    return;
                } else if (ann.getNameAsString().equals(BLOCK3_)) {
                    classWithMethodsListBlock3.put(classWithMethods.getPath(), classWithMethods);
                    return;
                }
            }

            classWithMethodsList.put(classWithMethods.getPath(), classWithMethods);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    // for every controller with some annotation Block finds all imports
    // and then calls parse method
    public void splitToBlocks() {
        Map<String, ClassWithMethods> classBlockList = new HashMap<>();

        classWithMethodsListBlock1.forEach((K, V) -> classBlockList.put(K, V));
        classBlockList.forEach((Key, class_) -> parseImports(Key, BLOCK1_));

        classBlockList.clear();
        classWithMethodsListBlock2.forEach((K, V) -> classBlockList.put(K, V));
        classBlockList.forEach((Key, class_) -> parseImports(Key, BLOCK2_));

        classBlockList.clear();
        classWithMethodsListBlock3.forEach((K, V) -> classBlockList.put(K, V));
        classBlockList.forEach((Key, class_) -> parseImports(Key, BLOCK3_));

        classBlockList.clear();
        classWithMethodsList.forEach((K, V) -> classBlockList.put(K, V));
        classBlockList.forEach((Key, class_) -> parseImportsFromUncategorizedClass(Key, class_));


    }

    private void parseImportsFromUncategorizedClass(String classNameWithPath, ClassWithMethods classWithMethods){
        // ziskam vsechny importy dane tridy
        List<ImportDeclaration> imports = getImportsFromClass(classNameWithPath);

        // upravim
        List<String> importsParsed = addImportsAsClassName(imports);
        // do listu naplnim vsechny classWithMethods, ktere se objevi v importu
        List<String> tempBlockList = new ArrayList<>();
        importsParsed.stream().forEach(y -> {
            for (Map.Entry<String, ClassWithMethods> entry: classWithMethodsListBlock1.entrySet()) {
                if(entry.getKey().substring(0, entry.getKey().lastIndexOf(".")).endsWith(y)){
                    classWithMethodsListBlock1.put(classNameWithPath, classWithMethods);
                    break;
                }
            }

            for (Map.Entry<String, ClassWithMethods> entry: classWithMethodsListBlock2.entrySet()) {
                if(entry.getKey().substring(0, entry.getKey().lastIndexOf(".")).endsWith(y)){
                    classWithMethodsListBlock2.put(classNameWithPath, classWithMethods);
                    break;
                }
            }

            for (Map.Entry<String, ClassWithMethods> entry: classWithMethodsListBlock3.entrySet()) {
                if(entry.getKey().substring(0, entry.getKey().lastIndexOf(".")).endsWith(y)){
                    classWithMethodsListBlock3.put(classNameWithPath, classWithMethods);
                    break;
                }
            }


        });
    }

    // dostane list trid
    private void parseImports(String classNameWithPath, String block) {

        // ziskam vsechny importy dane tridy
        List<ImportDeclaration> imports = getImportsFromClass(classNameWithPath);


        // upravim
        List<String> importsParsed = addImportsAsClassName(imports);

        // do listu naplnim vsechny classWithMethods, ktere se objevi v importu
        List<String> tempBlockList = new ArrayList<>();
        importsParsed.stream().forEach(y -> {
            classWithMethodsList.forEach((K, V) -> {
                // System.out.println("y= " + y);
                // System.out.println("K=" + K);
                if (K.substring(0, K.lastIndexOf(".")).endsWith(y)) {
                    tempBlockList.add(K);
                    // ulozit do hashmapy daneho bloku
                    if (block.equals(BLOCK1_)) {
                        classWithMethodsListBlock1.put(K, V);
                    } else if (block.equals(BLOCK2_)) {
                        classWithMethodsListBlock2.put(K, V);
                    } else if (block.equals(BLOCK3_)) {
                        classWithMethodsListBlock3.put(K, V);
                    }
                }
            });
        });

        // pro kazdou tridu rekurzivne zavolam znovu tuto metodu
        tempBlockList.stream().forEach(y -> parseImports(y, block));

    }


    private List<ImportDeclaration> getImportsFromClass(String path) {

        CompilationUnit cu = null;
        try {
            cu = JavaParser.parse(new FileInputStream(path));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return cu.getImports();
    }

    private List<String> addImportsAsClassName(List<ImportDeclaration> imports){

        // dany import upravim -> odebere strednik naknci a slovo import s mezerou
        // vymenim "." v importu za "/"
        return imports.stream().map(y -> {
            String import_ = y.toString();
            return import_.substring(import_.indexOf(" ") + 1, import_.lastIndexOf(";"))
                    .replace(".", "/");

        }).collect(Collectors.toList());
    }


    public void printAllClasses() {
        List<String> results = new ArrayList<>();

        /* */
        File[] files = new File(filePath).listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.endsWith(".java");
            }
        });

        for (File file : files) {
            if (file.isFile()) {
                results.add(file.getName());
            }
        }

        System.out.println("Size of all finded classes:" + results.size());


        List<ClassWithMethods> listOfClass = results.stream()
                .map(y -> {
                    CompilationUnit cu = null;
                    try {
                        cu = JavaParser.parse(new FileInputStream(filePath.concat("/" + y)));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    List<String> methodNames = new ArrayList<>();
                    VoidVisitor<List<String>> methodVisitor = new MethodNamePrinter();
                    methodVisitor.visit(cu, methodNames);

                    return new ClassWithMethods(y, filePath, methodNames);
                }).collect(Collectors.toList());

        listOfClass.forEach(System.out::println);
    }

    public Map<String, ClassWithMethods> getClassWithMethodsList() {
        return classWithMethodsList;
    }

    public Map<String, ClassWithMethods> getClassWithMethodsListBlock1() {
        return classWithMethodsListBlock1;
    }

    public Map<String, ClassWithMethods> getClassWithMethodsListBlock2() {
        return classWithMethodsListBlock2;
    }

    public Map<String, ClassWithMethods> getClassWithMethodsListBlock3() {
        return classWithMethodsListBlock3;
    }

    // vypis vsech anotaci
    private static class AnnotationVisitor extends VoidVisitorAdapter {
        @Override
        public void visit(MarkerAnnotationExpr n, Object arg) {
            System.out.println("Annotations:");
            System.out.println(n);
            System.out.println(arg);
            System.out.println(n.getName());
            System.out.println("=======================");
        }

        @Override
        public void visit(ClassOrInterfaceDeclaration n, Object arg) {
            super.visit(n, arg);
        }
    }

    /**
     * Visitor, ktery ulozi do listu collector vsechny anotace dane tridy
     */
    private static class ClassVisitor extends VoidVisitorAdapter<List<AnnotationExpr>> {
        @Override
        public void visit(ClassOrInterfaceDeclaration n, List<AnnotationExpr> collector) {
            super.visit(n, collector);
            for (AnnotationExpr ann : n.getAnnotations()) {
                collector.add(ann);

            }

        }
    }


    private static class MethodNamePrinter extends VoidVisitorAdapter<List<String>> {
        @Override
        public void visit(MethodDeclaration md, List<String> collector) {
            super.visit(md, collector);
            collector.add(md.getNameAsString());
        }
    }


    public static void main(String[] args) throws Exception {
        String FILE_PATH = "src/main/java/org/jboss/as/quickstarts/kitchensink/";

        Path fullPath = Paths.get(FILE_PATH);
        System.out.println("full " + fullPath.toString());
        Path abspath = fullPath.toAbsolutePath();
        System.out.println("abs " + abspath);


        ParserClass parserClass = new ParserClass(FILE_PATH);
        parserClass.findAllClasses(FILE_PATH);


        parserClass.splitToBlocks();

        System.out.println("======BLOCK1==========");
       // parserClass.getClassWithMethodsListBlock1().forEach((K, V) -> System.out.println(K));
        System.out.println("======BLOCK2==========");
      //  parserClass.getClassWithMethodsListBlock2().forEach((K, V) -> System.out.println(K));
        System.out.println("======BLOCK3==========");
      //  parserClass.getClassWithMethodsListBlock3().forEach((K, V) -> System.out.println(K));
        System.out.println("======REST==========");
     //   parserClass.getClassWithMethodsList().forEach((K, V) -> System.out.println(V.getPath()));


        CompilationUnit cu = null;
        try {
            cu = JavaParser.parse(new FileInputStream("src/main/java/org/jboss/as/quickstarts/kitchensink/dao/AuthorDAOImpl.java"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }



/*
        //zavolani tridy ClassVisitor a ulozeni vsech anotaci do listu
        List<AnnotationExpr> annotationClassList = new ArrayList<>();
        VoidVisitor<List<AnnotationExpr>> annotationClassVisitor = new ClassVisitor();
        annotationClassVisitor.visit(cu, annotationClassList);

        annotationClassList.stream().forEach(System.out::println);
        System.out.println("========================");
        List<ImportDeclaration> imports = cu.getImports();
        imports.stream().forEach(System.out::println);
        System.out.println(imports.size());
        System.out.println(cu.getPackageDeclaration());
*/
    }


}
